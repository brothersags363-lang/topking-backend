export type UploadStatus = 'uploading' | 'processing' | 'success' | 'failed';

export type UploadJob = {
  id: string;
  progress: number;
  status: UploadStatus;
  title?: string;
  error?: string;
};

type Listener = (jobs: UploadJob[]) => void;

const jobs = new Map<string, UploadJob>();
const listeners = new Set<Listener>();

function emit() {
  const snapshot = Array.from(jobs.values());
  listeners.forEach((listener) => listener(snapshot));
}

export function subscribeUploadJobs(listener: Listener) {
  listeners.add(listener);
  listener(Array.from(jobs.values()));
  return () => listeners.delete(listener);
}

export function createUploadJob(title = 'Video') {
  const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  jobs.set(id, { id, progress: 0, status: 'uploading', title });
  emit();
  return id;
}

export function updateUploadJob(id: string, patch: Partial<UploadJob>) {
  const current = jobs.get(id);
  if (!current) return;
  jobs.set(id, { ...current, ...patch });
  emit();
}

export function finishUploadJob(id: string) {
  updateUploadJob(id, { progress: 100, status: 'success' });
  setTimeout(() => {
    jobs.delete(id);
    emit();
  }, 7000);
}

export function failUploadJob(id: string, error: unknown) {
  updateUploadJob(id, {
    status: 'failed',
    error: error instanceof Error ? error.message : String(error),
  });
}

/**
 * Keeps the upload promise independent from the Post screen while the app
 * remains open. The existing upload logic is passed as the task callback.
 */
export function runInBackground<T>(
  task: (jobId: string) => Promise<T>,
  title = 'Video upload',
) {
  const jobId = createUploadJob(title);

  Promise.resolve()
    .then(() => task(jobId))
    .then(() => finishUploadJob(jobId))
    .catch((error) => failUploadJob(jobId, error));

  return jobId;
}
